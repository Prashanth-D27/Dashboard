import React from 'react';
import './App.css';
import RouterUse from './Router/Router';

function App() {
  return (
    <>
    <div className='App'>
      <RouterUse />
      </div>
    </>
  );
}

export default App;
