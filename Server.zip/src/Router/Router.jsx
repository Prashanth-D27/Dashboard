import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import '../App.css';
import Home from '../view/Home';
import Layout from '../view/Layout';
import Details from '../view/Details';
import Login from '../view/Login';

function RouterUse() {
  return (
    <Router>
      <div className='App'>
        <Routes>
          <Route path='/' element={<Login />} />
          <Route path='/home' element={<Layout><Home /></Layout>} />
          <Route path='/details' element={<Layout><Details /></Layout>} />
        </Routes>
      </div>
    </Router>
  );
}

export default RouterUse;
