import React from 'react';
import { Select } from 'antd';

const { Option } = Select;

const DropdownButton = ({ value, onChange }) => {
  return (
    <Select value={value} onChange={onChange} style={{ width: '100%' }}>
      <Option value="Ac">Ac</Option>
      <Option value="Non-Ac">Non-Ac</Option>
    </Select>
  );
};

export default DropdownButton;
