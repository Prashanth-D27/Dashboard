import React from 'react';
import { Select } from 'antd';

const { Option } = Select;

const AnotherButton = ({ value, onChange }) => {
  return (
    <Select value={value} onChange={onChange} style={{ width: '100%' }}>
      <Option value="Cash">Cash</Option>
      <Option value="Card">Card</Option>
      <Option value="Online">Online</Option>
    </Select>
  );
};

export default AnotherButton;
