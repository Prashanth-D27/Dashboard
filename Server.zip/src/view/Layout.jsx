import React, { useState } from 'react';
import { HomeOutlined, TeamOutlined } from '@ant-design/icons';
import { Menu } from 'antd';
import { useNavigate } from 'react-router-dom';
import "../Styles/Stylemain.css";

const items = [
  {
    label: 'Home',
    key: 'home', 
    icon: <HomeOutlined />
  },
  {
    label: 'Customer',
    key: 'customer',
    icon: <TeamOutlined />
  }
];

const Layout = ({children}) => {
  const [current, setCurrent] = useState('home'); 
  const navigate = useNavigate(); 

  const onClick = (e) => {
    console.log('click ', e);
    setCurrent(e.key);

    switch (e.key) {
      case 'home':
        navigate('/home');
        break;
      case 'customer':
        navigate('/details');
        break;
      default:
        break;
    }
  };

  return (
    <>
      <Menu onClick={onClick} selectedKeys={[current]} mode="horizontal" items={items} />
      <main className="layout-content">
        {children}
      </main>
    </>
  );
};

export default Layout;
