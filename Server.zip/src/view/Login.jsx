import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button, Checkbox, Form, Input, message } from 'antd';
import '../Styles/Style.css';
import LoginImg from '../Images/Background.png';

const Login = () => {
  const navigate = useNavigate();

  const onFinish = (values) => {
    const { username, password, employeeId } = values;
    const correctUsername = 'Prashanth';
    const correctPassword = 'Pras27';
    const correctEmployeeId = 'Prashanth27';
    if (
      username === correctUsername &&
      password === correctPassword &&
      employeeId === correctEmployeeId
    ) {
      console.log('Success:', values);
      navigate('/home');
    } else {
      message.error('Invalid credentials. Please try again.');
    }
  };

  const onFinishFailed = (errorInfo) => {
    console.log('Failed:', errorInfo);
  };

  return (
    <>
      <div className="Container">
        <div className="Bg-img"> 
          <img src={LoginImg} alt="login img" />
        </div>
        <h3>Login to your account</h3>
        <div className="Login">
          
          <Form
            name="login"
            labelCol={{ span: 8 }}
            wrapperCol={{ span: 16 }}
            style={{ maxWidth: 360 }}
            initialValues={{ remember: true }}
            onFinish={onFinish}
            onFinishFailed={onFinishFailed}
            autoComplete="off"
          >
            <div className="Box1">
              <Form.Item
                className='Input'
                label="Employee Id"
                name="employeeId"
                rules={[{ required: true, message: 'Please input your Employee Id!' }]}
              >
                <Input className="Type-box" />
              </Form.Item>
            </div>
            <Form.Item
              className='Input'
              label="Username"
              name="username"
              rules={[{ required: true, message: 'Please input your username!' }]}
            >
              <Input className="Type-box" />
            </Form.Item>
            <Form.Item
              className='Input'
              label="Password"
              name="password"
              rules={[{ required: true, message: 'Please input your password!' }]}
            >
              <Input.Password className="Type-box" />
            </Form.Item>

            <Form.Item
              name="remember"
              valuePropName="checked"
              wrapperCol={{ offset: 8, span: 16 }}
            >
              <Checkbox>Remember me</Checkbox>
            </Form.Item>

            <Form.Item wrapperCol={{ offset: 8, span: 16 }}>
              <Button className="Submit" type="primary" htmlType="submit">
                Submit
              </Button>
            </Form.Item>
          </Form>
        </div>
      </div>
    </>
  );
};

export default Login;
