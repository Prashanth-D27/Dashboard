import React from 'react';
import StatusImg from "../Images/images.png"
import "../Styles/Stylemain.css";

const Status = () =>{
    return (
    <>
        <div className="Final">
            <h3 className='h3-last'>All Done!</h3>
        <img className="Last-img" src={StatusImg} alt="Status img"></img>
        <h6>Details Entered Sucessfully!</h6>
        </div>
    </>
  );
};

export default Status;
