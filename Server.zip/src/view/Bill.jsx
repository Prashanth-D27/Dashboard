import React from 'react';
import { DatePicker, Form, Input, Button } from 'antd';
import "../Styles/Stylemain.css";
import AnotherButton from '../AnotherButton';

const Bill = ({ onFinish }) => {
  const [form] = Form.useForm();

  const handleFinish = (values) => {
    console.log('Form values:', values); 
    const formattedValues = {
      ...values,
      paymentDateTime: values.paymentDateTime ? values.paymentDateTime.format('YYYY-MM-DD HH:mm:ss') : null,
    };
    onFinish(formattedValues);
    form.resetFields(); 
  };

  const onFinishFailed = (errorInfo) => {
    console.log('Failed:', errorInfo);
  };

  return (
    <div>
      <Form
        form={form}
        name="billForm"
        labelCol={{ span: 8 }}
        wrapperCol={{ span: 16 }}
        style={{ maxWidth: 1350, height: 200 , marginBottom: 170 }}
        initialValues={{ remember: true }}
        onFinish={handleFinish}
        onFinishFailed={onFinishFailed}
        autoComplete="off"
      >
        <Form.Item
          className='Cus-Box'
          layout="vertical"
          label="Customer Id"
          name="customerId"
          rules={[{ required: true, message: 'Please input your Customer Id!' }]}
        >
          <Input />
        </Form.Item>

        <Form.Item
          className='Cus-Box'
          layout="vertical"
          label="Customer Name"
          name="customerName"
          rules={[{ required: true, message: 'Please input your Customer Name!' }]}
        >
          <Input />
        </Form.Item>

        <Form.Item
          className='Cus-Box'
          layout="vertical"
          label="Phone Number"
          name="phoneNumber"
          rules={[{ required: true, message: 'Please input your Phone Number!' }]}
        >
          <Input />
        </Form.Item>

        <Form.Item
          className='Cus-Box'
          layout="vertical"
          label="Email"
          name="email"
          rules={[{ required: true, message: 'Please input your Email!' }]}
        >
          <Input />
        </Form.Item>

        <Form.Item
          className='Cus-Box'
          layout="vertical"
          label="Invoice Id"
          name="invoiceId"
          rules={[{ required: true, message: 'Please input Invoice Id!' }]}
        >
          <Input />
        </Form.Item>

        <Form.Item
          className='Cus-Box'
          layout="vertical"
          label="Booking Id"
          name="bookingId"
          rules={[{ required: true, message: 'Please input your Booking Id!' }]}
        >
          <Input />
        </Form.Item>

        <Form.Item
          className='Cus-Box'
          layout="vertical"
          label="Payment Date & Time"
          name="paymentDateTime"
          rules={[{ required: true, message: 'Please input Payment Date & Time!' }]}
        >
          <DatePicker showTime format="YYYY-MM-DD HH:mm:ss" />
        </Form.Item>

        <Form.Item
          className='Cus-Box'
          layout="vertical"
          label="Payment Method"
          name="paymentMethod"
          rules={[{ required: true, message: 'Please input Payment Method!' }]}
        >
          <AnotherButton />
        </Form.Item>

        <Form.Item
          className='Cus-Box'
          layout="vertical"
          label="Total Amount"
          name="totalAmount"
          rules={[{ required: true, message: 'Please input Total Amount!' }]}
        >
          <Input />
        </Form.Item>

        <Form.Item wrapperCol={{ offset: 8, span: 16 }}>
          <Button className='Save2'type="primary" htmlType="submit">
            Save
          </Button>
        </Form.Item>
      </Form>
    </div>
  );
};

export default Bill;
