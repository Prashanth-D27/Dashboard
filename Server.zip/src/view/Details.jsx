import React, { useState, useEffect } from 'react';
import { Button, Table } from 'antd';
import axios from 'axios';

const columns = [
  {
    title: 'Customer ID',
    dataIndex: 'Customer_Id',
  },
  {
    title: 'Customer Name',
    dataIndex: 'Customer_Name',
  },
  {
    title: 'Invoice_ID',
    dataIndex: 'Invoice_Id',
  },
  {
    title: 'Booking ID',
    dataIndex: 'Booking_Id',
  },
  {
    title: 'Check In Date',
    dataIndex: 'Check_In_Date', 
  },
  {
    title: 'Amount',
    dataIndex: 'Total_Amount',
  },
];

const Details = () => {
  const [dataSource, setDataSource] = useState([]);
  const [selectedRowKeys, setSelectedRowKeys] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    try {
      const response = await axios.get('http://localhost:3001/View-form');
      console.log('Data fetched:', response.data); 
      setDataSource(response.data);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const start = () => {
    setLoading(true);
    setTimeout(() => {
      setSelectedRowKeys([]);
      setLoading(false);
    }, 1000);
  };

  const onSelectChange = (newSelectedRowKeys) => {
    console.log('selectedRowKeys changed: ', newSelectedRowKeys);
    setSelectedRowKeys(newSelectedRowKeys);
  };

  const rowSelection = {
    selectedRowKeys,
    onChange: onSelectChange,
  };

  const hasSelected = selectedRowKeys.length > 0;

  return (
    <div style={{ padding: '24px' }}>
      <div style={{ marginBottom: '16px' }}>
        <Button type="primary" onClick={start} disabled={!hasSelected} loading={loading}>
          Reload
        </Button>
        {hasSelected ? `Selected ${selectedRowKeys.length} items` : null}
      </div>
      <Table 
        rowSelection={rowSelection} 
        columns={columns} 
        dataSource={dataSource} 
        loading={loading} 
        rowKey="Customer_Id"
      />
    </div>
  );
};

export default Details;

