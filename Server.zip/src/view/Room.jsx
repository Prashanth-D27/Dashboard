import React from 'react';
import { Form, Input, Radio, Button } from 'antd';
import "../Styles/Stylemain.css";
import DropdownButton from '../Dropdown';

const Room = ({ onFinish }) => {
  const [form] = Form.useForm();

  const handleFinish = (values) => {
    console.log('Form values:', values); 
    onFinish(values);
    form.resetFields();
  };

  const onFinishFailed = (errorInfo) => {
    console.log('Failed:', errorInfo);
  };

  return (
    <div>
      <Form
        form={form}
        name="roomForm"
        labelCol={{ span: 8 }}
        wrapperCol={{ span: 16 }}
        style={{ maxWidth: 1350, height: 150, marginBottom: 220 }}
        initialValues={{ remember: true }}
        onFinish={handleFinish}
        onFinishFailed={onFinishFailed}
        autoComplete="off"
      >
        <Form.Item
          className='Cus-Box'
          layout="vertical"
          label="Room No"
          name="roomNo"
          rules={[{ required: true, message: 'Please input your Room No!' }]}
        >
          <Input />
        </Form.Item>

        <Form.Item
          className='Cus-Box'
          layout="vertical"
          label="No of Rooms"
          name="noOfRooms"
          rules={[{ required: true, message: 'Please input your No Of Rooms!' }]}
        >
          <Input />
        </Form.Item>

        <Form.Item
          className='Cus-Box'
          layout="vertical"
          label="Room Type"
          name="roomType"
          rules={[{ required: true, message: 'Please select Room Type!' }]}
        >
          <DropdownButton />
        </Form.Item>

        <Form.Item
          className='Cus-Box'
          layout="vertical"
          label="Food Accommodation"
          name="foodAccomodation"
          rules={[{ required: true, message: 'Select Food Accommodation!' }]}
        >
          <Radio.Group>
            <Radio value="Yes">Yes</Radio>
            <Radio value="No">No</Radio>
          </Radio.Group>
        </Form.Item>

        <Form.Item
          className='Cus-Box'
          layout="vertical"
          label="Extra Bed"
          name="extraBed"
          rules={[{ required: true, message: 'Select Extra Bed!' }]}
        >
          <Radio.Group>
            <Radio value="Yes">Yes</Radio>
            <Radio value="No">No</Radio>
          </Radio.Group>
        </Form.Item>

        <Form.Item
          className='Cus-Box'
          layout="vertical"
          label="Amount"
          name="amount"
          rules={[{ required: true, message: 'Please input your Amount!' }]}
        >
          <Input />
        </Form.Item>

        <Form.Item wrapperCol={{ offset: 8, span: 16 }}>
          <Button className='Save1' type="primary" htmlType="submit">
            Save
          </Button>
        </Form.Item>
      </Form>
    </div>
  );
};

export default Room;
