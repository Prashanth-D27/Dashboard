import React from 'react';
import { Form, Input, Checkbox, Button } from 'antd';
import "../Styles/Stylemain.css";

const Customer = ({ onFinish }) => {
  const [form] = Form.useForm();

  const handleFinish = (values) => {
    console.log('Form values:', values); 
    onFinish(values)
    form.resetFields()
  };

  const onFinishFailed = (errorInfo) => {
    console.log('Failed:', errorInfo);
  };

  return (
    <div>
      <Form
        form={form}
        name="customerForm"
        labelCol={{ span: 8 }}
        wrapperCol={{ span: 16 }}
        style={{ maxWidth: 1350, height: 302 }}
        initialValues={{ remember: true }}
        onFinish={handleFinish}
        onFinishFailed={onFinishFailed}
        autoComplete="off"
      >
        <Form.Item
          className='Cus-Box'
          layout="vertical"
          label="Customer Id"
          name="customerId"
          rules={[{ required: true, message: 'Please input your Customer Id!' }]}
        >
          <Input />
        </Form.Item>

        <Form.Item
          className='Cus-Box'
          layout="vertical"
          label="Customer Name"
          name="customerName"
          rules={[{ required: true, message: 'Please input your Customer Name!' }]}
        >
          <Input />
        </Form.Item>

        <Form.Item
          className='Cus-Box'
          layout="vertical"
          label="Phone Number"
          name="phoneNumber"
          rules={[{ required: true, message: 'Please input your Phone Number!' }]}
        >
          <Input />
        </Form.Item>

        <Form.Item
          className='Cus-Box'
          layout="vertical"
          label="Email"
          name="email"
          rules={[{ required: true, message: 'Please input a valid Email!' }]}
        >
          <Input />
        </Form.Item>

        <Form.Item
          className='Cus-Box'
          layout="vertical"
          label="No of Members"
          name="noOfMembers"
          rules={[{ required: true, message: 'Please input the number of members!' }]}
        >
          <Input />
        </Form.Item>

        <Form.Item
          className='Cus-Box'
          layout="vertical"
          label="Booking Id"
          name="bookingId"
          rules={[{ required: true, message: 'Please input your Booking Id!' }]}
        >
          <Input />
        </Form.Item>

        <Form.Item
          className='Cus-Box'
          layout="vertical"
          label="No of Adult"
          name="noOfAdult"
          rules={[{ required: true, message: 'Please input the number of adults!' }]}
        >
          <Input />
        </Form.Item>

        <Form.Item
          className='Cus-Box'
          layout="vertical"
          label="No of Child"
          name="noOfChild"
          rules={[{ required: true, message: 'Please input the number of children!' }]}
        >
          <Input />
        </Form.Item>

        <Form.Item
          className='Cus-Box'
          layout="vertical"
          label="No Of Senior Citizen"
          name="noOfSeniorCitizen"
          rules={[{ required: true,  message: 'Please input the number of senior citizens!' }]}
        >
          <Input />
        </Form.Item>

        <Form.Item
          className='Cus-Box'
          layout="vertical"
          label="Total Amount"
          name="totalAmount"
          rules={[{ required: true, message: 'Please input the total amount!' }]}
        >
          <Input />
        </Form.Item>

        <Form.Item
          className='Cus-Box'
          layout="vertical"
          label="Government ID"
          name="governmentId"
          rules={[{ required: true, message: 'Please select your Government ID!' }]}
        >
          <Checkbox.Group>
            <Checkbox value="Aadhar Card">Aadhar Card</Checkbox>
            <Checkbox value="Pan Card">Pan Card</Checkbox>
            <Checkbox value="Driving License">Driving License</Checkbox>
          </Checkbox.Group>
        </Form.Item>

        <Form.Item
          className='Cus-Box'
          layout="vertical"
          label="Card Number"
          name="cardNumber"
          rules={[{ required: true, message: 'Please input your Card Number!' }]}
        >
          <Input />
        </Form.Item>

        <Form.Item wrapperCol={{ offset: 8, span: 16 }}>
          <Button className='Save' type="primary" htmlType="submit">
            Save
          </Button>
        </Form.Item>
      </Form>
    </div>
  );
};

export default Customer;
