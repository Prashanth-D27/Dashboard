import React, { useState } from 'react';
import { Button, message, Steps, theme } from 'antd';
import Customer from './Customer';
import Room from './Room';
import Bill from './Bill';
import Status from './Status';
import { Footer } from 'antd/es/layout/layout';
import axios from 'axios';

const steps = [
  {
    title: 'Customer',
    component: Customer,
  },
  {
    title: 'Room',
    component: Room,
  },
  {
    title: 'Bill',
    component: Bill,
  },
  {
    title: 'Status',
    component: Status,
  }
];

const Home = () => {
  const { token } = theme.useToken();
  const [current, setCurrent] = useState(0);
  const [formValues, setFormValues] = useState({});

  const next = () => {
    if (current < steps.length - 1) {
      setCurrent(current + 1);
    }
  };

  const onFinish = (values) => {
    setFormValues(prevValues => ({
      ...prevValues,
      ...values
    }));
  };

  const handleDone = () => {
    axios.post('http://localhost:3001/submit-form', formValues)
      .then(response => {
        console.log('Form Submission Success:', response.data);
        message.success('Form submitted successfully!');
      
        return axios.post('http://localhost:3001/populate-details');
      })
      .then(response => {
        console.log('Populate Details Success:', response.data);
        message.success('Details table populated successfully!');
        setFormValues({});
        setCurrent(0);
      })
      .catch(error => {
        console.error('Error:', error.response ? error.response.data : error.message);
        message.error('Operation failed');
      });
  };

  const items = steps.map((item) => ({
    key: item.title,
    title: item.title,
  }));

  const contentStyle = {
    lineHeight: '260px',
    textAlign: 'center',
    color: token.colorTextTertiary,
    margin: 16
  };

  const StepComponent = steps[current].component;

  return (
    <>
      <Steps current={current} items={items} />
      <div style={contentStyle}>
        <StepComponent onFinish={onFinish} />
      </div>
      <div style={{ marginTop: 24 }}>
        <Footer>
          {current < steps.length - 1 && (
            <Button type="primary" onClick={next}>
              Next
            </Button>
          )}
          {current === steps.length - 1 && (
            <Button type="primary" onClick={handleDone}>
              Done
            </Button>
          )}
        </Footer>
      </div>
    </>
  );
};

export default Home;
