const express = require('express');
const mysql = require('mysql2/promise');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const port = 3001;

const dbConfig = {
  host: 'localhost',
  user: 'root',
  password: 'root_one',
  database: 'hotelmanagement'
};

app.use(cors());
app.use(bodyParser.json());

app.post('/submit-form', async (req, res) => {
  console.log( 'Data Inserted Succesfully', req.body);
  const { 
    customerId, customerName, phoneNumber, email, noOfMembers, bookingId, 
    noOfAdult, noOfChild, noOfSeniorCitizen, totalAmount, governmentId, 
    cardNumber, roomNo, noOfRooms, roomType, foodAccomodation, extraBed, 
    amount, invoiceId, paymentDateTime, paymentMethod 
  } = req.body;

  let connection;
  try {
    connection = await mysql.createConnection(dbConfig);
    await connection.beginTransaction();

    await connection.query(
      'INSERT INTO customer (Customer_Id, Customer_Name, Phone_Number, Email, No_Of_Members, Booking_Id, No_Of_Adult, No_Of_Child, No_Of_Senior_Citizen, Total_Amount, Government_Id, Card_Number) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
      [customerId, customerName, phoneNumber, email, noOfMembers, bookingId, noOfAdult, noOfChild, noOfSeniorCitizen, totalAmount, JSON.stringify(governmentId), cardNumber]
    );


    await connection.query(
      'INSERT INTO room (Room_No, No_Of_Rooms, Room_Type, Food_Accomodation, Extra_Bed, Amount) VALUES (?, ?, ?, ?, ?, ?)',
      [roomNo, noOfRooms, roomType, JSON.stringify(foodAccomodation), JSON.stringify(extraBed), amount]
    );

    await connection.query(
      'INSERT INTO bill (Customer_id, Customer_Name, Phone_Number, Email, Inovoice_Id, Booking_Id, Payment_Date_Time, Payment_Method, Total_Amount) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
      [customerId, customerName, phoneNumber, email, invoiceId, bookingId, paymentDateTime, paymentMethod, totalAmount]
    );

    await connection.commit();
    res.status(200).json({ message: 'Data inserted successfully' });
  } catch (err) {
    console.error('Error during transaction:', err);
    if (connection) {
      try {
        await connection.rollback();
      } catch (rollbackErr) {
        console.error('Error during rollback:', rollbackErr);
      }
    }
    res.status(500).json({ error: 'Error inserting data', details: err.message });
  } finally {
    if (connection) {
      await connection.end();
    }
  }
});

app.post('/populate-details', async (req, res) => {
  let connection;
  try {
    connection = await mysql.createConnection(dbConfig);
    await connection.query('TRUNCATE TABLE details');
    await connection.query(`
      INSERT INTO details (Customer_Id, Customer_Name, Invoice_Id, Booking_Id, Check_In_Date, Total_Amount)
      SELECT
        customer.Customer_Id,
        customer.Customer_Name,
        bill.Inovoice_Id,
        bill.Booking_Id,
        bill.Payment_Date_Time AS Check_In_Date,
        bill.Total_Amount
      FROM
        customer
      INNER JOIN
        bill ON customer.Customer_Id = bill.Customer_Id
    `);
    res.status(200).json({ message: 'Details table populated successfully' });
  } catch (error) {
    console.error('Error populating details table:', error);
    res.status(500).json({ error: 'Error populating details table', details: error.message });
  } finally {
    if (connection) {
      await connection.end();
    }
  }
});

app.get('/View-form', async (req, res) => {
  let connection;
  try {
    connection = await mysql.createConnection(dbConfig);
    const [results] = await connection.query('SELECT * FROM details');
    res.json(results);
  } catch (error) {
    console.error('Error fetching data:', error);
    res.status(500).json({ error: 'Database query failed', details: error.message });
  } finally {
    if (connection) {
      await connection.end();
    }
  }
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
